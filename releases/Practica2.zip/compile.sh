#!/usr/bin/bash

flex -o src/lexical/lex.yy.c src/lexical/python.l

if [ $? -ne 0 ]; then
    echo "Flex failed"
    exit 1
fi

echo ""
echo ""

make

if [ $? -ne 0 ]; then
    echo "Compilation failed"
    exit 1
fi