# Instrucciones Práctica 2 Compiladores
Este documento recolle a información básica sobre o proxecto necesaria para poder entender como se estrutura e para poder realizar a compilación e execución do mesmo.

Para comprender como funciona o código, apórtanse os comentarios necesarios dentro do mesmo para unha mellor comprensión.

## Versións de programas
+ GCC:
```
gcc version 10.2.1
```
+ Flex:
```
flex 2.6.4
```

## Estructura de carpetas 📂
O proxecto encóntrase dentro da carpeta **src/**. Dentro están todos os ficheiros de código fonde e cabeceiras necesarias. Atoparemos as seguintes carpetas e ficheiros:
 
 + *main.c*: invoca a execución do compilador
 + **ts/**: contén a táboa de símbolos e a estructura de datos (neste caso un hashmap con encadeamento)
 + **syntactic/**: contén o analizador sintáctico
 + **lexical/**: contén o analizador léxico
 + **error/**: contén a xestión de erros do compilador
 + **common/**: contén ficheiros de definicións comúns ao resto de módulos do compilador

## Compilación 🤖
Xunto co código fonde, adxúntase un *Makefile* e un script de bash que permite compilar o proxecto.

Tendo a seguinte estructura de carpetas:
+ **src/**
    + *main.c:
    + **ts/**
    + **syntactic/**
    + **lexical/**
    + **error/**
    + **common/**
+ *Makefile*
+ *compile.sh*
+ *wilcoxon.py*

Para compilar, executar o seguinte comando situándose no mesmo nivel que o script *compile.sh*:
```
./compile.sh
```

Isto xerará o ficheiro .c de flex e invocará o makefile, que creará un directorio chamado **bin/** que terá no seu interior o código obxecto e o executable do compilador.


## Execución 💻
Para executar o compilador, estando na carpeta raíz:
```
./bin/compiler wilcoxon.py
```
**O segundo argumento do compilador é obrigatorio e correspondese co path ao ficheiro de código fonte**. O path pode ser relativo ou absoluto. 